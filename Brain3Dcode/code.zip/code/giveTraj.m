function [k1_new,k,nS] = giveTraj(ks, phi, theta,mtx_acq,mtx_reco,factor)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

  ks = squeeze(ks);
  nks = size(ks,1);
  nviews = size(phi,2);
  k = zeros(nks,nviews,3,class(ks));
            
  sinphi = sind(phi);
  cosphi = cosd(phi);
  sintheta = sind(theta);
  costheta = cosd(theta);
            
  k(:,:,1) =  ks(:,1)*(costheta.*cosphi) + ...
                ks(:,2)*(sinphi) - ...
                ks(:,3)*(sintheta.*cosphi);
  k(:,:,2) =  -ks(:,1)*(costheta.*sinphi) + ...
                ks(:,2)*(cosphi) + ...
                ks(:,3)*(sintheta.*sinphi);
  k(:,:,3) = ks(:,1)*(sintheta) + ...
                ks(:,3)*(costheta);
            % k = permute(k,[2 1 3]);
  k = reshape(k,nks,nviews,3);

  k1 = k*factor*mtx_acq/mtx_reco; 

    if(mtx_reco>mtx_acq)
        nS = nks;
    else
        nS = floor(nks*mtx_reco/mtx_acq);
    end

    k1_new = reshape(k1(1:nS,:,:),nS*nviews,3);

end

