cd '/Users/jcb/abdul_brain'
addpath('/Users/jcb/MRSI/matlab_mns');
addpath('/Users/jcb/MRSI/MNS-Aug19/read_MR_MR27_7T');

addpath(genpath('./../../gpuNUFFT'));
addpath(genpath('./../../Fessler-nufft'));
addpath(genpath('/Users/jcb/nfft2/matlab/nfft'));
addpath('/Users/jcb/bm4d/');
addpath(genpath('/Users/jcb/bm4d/MRIDenoisingPackage_r01_pcode'));

d = './../17Jan20/P49152_rfs2.7';
%d = './20200113_141044_P32768.7';
%d = './17Jan20/P52224.7'
wf_name = './../17Jan20/radial3D_1H_fov224_mtx448_intlv101460_kdt4_gmax17_smax118_dur1p6_coca.mat';
[dd,k,dcf,mtx_acq,nangles,fov,phi,theta]  = readradial(d,[],wf_name);

nsamples = length(dcf)/nangles;

nCh = size(dd,1);
dd = reshape(dd,nCh,nsamples,nangles);
k = reshape(k,nsamples,nangles,3);
dcf = reshape(dcf,nsamples,nangles);

ind = ones(size(dd,2),size(dd,3));
for i=1:1140:nangles,
    dd(:,:,i:i+2)=0;
    ind(:,i:i+2)=0;
end

%%
load(wf_name);
phi(1,50730:end) = phi(1,50730:end);
theta(1,50730:end) = theta(1,50730:end);
mtx_reco = 220;

[k1_new,~,nS] = giveTraj(ks, phi, theta,mtx_acq,mtx_reco,1.2);

    
dd_new = reshape(dd(:,1:nS,:),[nCh,nS*nangles]);
dcf_new = reshape(dcf(1:nS,:),nS*nangles,1);


 
osf = 2; % oversampling: 1.5 1.25
wg = 3; % kernel width: 5 7
sw = 8; % parallel sectors' width: 12 16

FT = gpuNUFFT(transpose(k1_new),ones(size(dcf_new)),osf,wg,sw,[1 1 1]*mtx_reco,[],true);

tic;init_recon = FT'*bsxfun(@times,dd_new(:,:)',(dcf_new));toc  

imagesc(abs(init_recon(:,:,110,2)))

q = transpose(FT*init_recon);
error = norm(abs(q(:)-dd_new(:)))
