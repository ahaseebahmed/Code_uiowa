# ge_pfile_matlab
Hacks to read p-file version 24.000
